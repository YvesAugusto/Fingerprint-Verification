import matplotlib.pyplot as plt
import numpy as np
import math
import scipy.ndimage