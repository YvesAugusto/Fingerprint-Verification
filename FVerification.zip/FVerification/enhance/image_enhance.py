# -*- coding: utf-8 -*-
"""
Created on Mon Apr 18 22:50:30 2016

@author: utkarsh
"""
from .segmentEnhance import segmentEnhance
from .orientEnhance import orientEnhance
from .freqEnhance import freqEnhance
from .filterEnhance import filterEnhance
import matplotlib.pyplot as plt

def image_enhance(img):
    blockSize = 16
    thresh = 0.1
    normim,mask = segmentEnhance(img,blockSize,thresh)         # normalise the image and find a ROI


    gradientsigma = 1
    blocksigma = 7
    orientsmoothsigma = 7
    orientim = orientEnhance(normim, gradientsigma, blocksigma, orientsmoothsigma)             # find orientation of every pixel


    blockSize = 38
    windsze = 5
    minWaveLength = 5
    maxWaveLength = 15
    freq,medfreq = freqEnhance(normim, mask, orientim, blockSize, windsze, minWaveLength,maxWaveLength)    #find the overall frequency of ridges

    
    freq = medfreq*mask
    kx = 0.65
    ky = 0.65
    newim = filterEnhance(normim, orientim, freq, kx, ky)       # create gabor filterEnhance and do the actual filterEnhanceing

    
    #th, bin_im = cv2.threshold(np.uint8(newim),0,255,cv2.THRESH_BINARY)
    return(newim < -3)